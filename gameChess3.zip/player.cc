#include "player.h"

// Player::~Player() {}

Player::Player(int color) : color{color} {}
